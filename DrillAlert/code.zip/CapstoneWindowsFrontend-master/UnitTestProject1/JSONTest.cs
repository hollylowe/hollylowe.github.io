﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDIApp;

namespace UnitTestProject1
{
    [TestClass]
    public class JSONTest
    {
        [TestMethod]
        public void TestGetCurve()
        {
            Curve curve = JSONManager.getCurve(0, 0);
        }
    }
}
