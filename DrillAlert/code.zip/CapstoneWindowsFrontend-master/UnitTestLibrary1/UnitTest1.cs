﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestPlatform.UnitTestFramework;

namespace UnitTestLibrary1
{
    [TestClass]
    public class TestManageAlerts
    {
        [TestMethod]
        public void TestGetWells()
        {
            Assert.IsNull(ManageAlerts.Wells);
            ManageAlerts.getWells();
            Assert.IsNotNull(ManageAlerts.Wells);
        }

        [TestMethod]
        public void TestGetWellbores()
        {
            Assert.IsNull(ManageAlerts.Wellbores);
            ManageAlerts.WellSelectionChanged(null, null);
            Assert.IsNotNull(ManageAlerts.Wellbores);
        }

        [TestMethod]
        public void TestGetCurves()
        {
            Assert.IsNull(ManageAlerts.Curves);
            ManageAlerts.WellboreSelectionChanged(null, null);
            Assert.IsNotNull(ManageAlerts.Curves);
        }

        [TestMethod]
        public void TestGetAlerts()
        {
            Assert.IsNull(ManageAlerts.associatedAlerts);
            ManageAlerts.ParameterSelectionChanged(null, null);
            Assert.IsNotNull(ManageAlerts.associatedAlerts);
        }
    }
}
