﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    public class Alert
    {
        public enum Severity { Information, Warning, Critical };

        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int CurveId { get; set; }
        [DataMember]
        public bool Rising { get; set; }
        [DataMember]
        public int WellBoreId { get; set; }
        [DataMember]
        public string Priority { get; set; }
        [DataMember]
        public double Threshold { get; set; }

        /*
         * Create an alert with the specified values. The curve id specifies the parameter being measured, on the specified wellbore.
         * If rising is true, the alert will trigger when the value passes above the threshold, otherwise it will trigger when
         * the value passes below the threshold.
         */
        public Alert(string name, int curveId, bool rising, int wellboreId, Severity priority, double threshold)
        {
            this.Name = name;
            this.CurveId = curveId;
            this.Rising = rising;
            this.WellBoreId = wellboreId;
            this.Priority = priority.ToString();
            this.Threshold = threshold;
        }

        public override string ToString()
        {
            return "Name: " + Name + " WellboreId: " + WellBoreId + " CurveId: " + CurveId;
        }
    }
}
