﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    class CurveManager
    {
        private static CurveManager instance;

        public static CurveManager Instance
        {
            get 
            {
                if (instance == null)
                {
                    instance = new CurveManager();
                }
                return instance;
            }
        }

        public async Task<Curve> getCurve(int wellboreId, int curveId)
        {
            Curve[] curves = await JSONManager.getCurvePoints(wellboreId, curveId);
            return curves[0];
        }
    }
}
