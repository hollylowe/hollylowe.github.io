﻿using SDIApp.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Windows.Input;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Split Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234234

namespace SDIApp
{
    /// <summary>
    /// A page that displays a group title, a list of items within the group, and details for
    /// the currently selected item.
    /// </summary>
    public sealed partial class Settings : Page, IObserver<View>
    {
        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();
        Panel currentPanel;

        Flyout newVisualPopup;
        StackPanel newVisualPanel;
        TextBox newVisualNameBox;
        ComboBox newVisualTypeComboBox;
        Button newVisualCreateButton;
        TextBlock newVisualTitle;

        private ComboBox newItemCurveIDComboBox;
        private TextBox newItemNameBox;
        private MessageDialog deleteConfirmationDialog;
        private Button createItemButton;

        private bool deleteItemMode;

        /// <summary>
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// NavigationHelper is used on each page to aid in navigation and 
        /// process lifetime management
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        public Settings()
        {
            this.InitializeComponent();

            // Setup the navigation helper
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += navigationHelper_LoadState;
            this.navigationHelper.SaveState += navigationHelper_SaveState;

            newVisualPopup = new Flyout();
            newVisualPanel = new StackPanel();
            newVisualNameBox = new TextBox();
            newVisualTypeComboBox = new ComboBox();
            
            newVisualCreateButton = new Button();
            newVisualTitle = new TextBlock();

            newVisualTitle.Text = "New Page";

            newVisualCreateButton.Content = "Create";
            newVisualCreateButton.Click += NewVisualCreate_Click;

            newVisualNameBox.Header = "Name";
            newVisualNameBox.TextChanged += NameText_Changed;

            newVisualTypeComboBox.ItemsSource = Enum.GetNames(typeof(PanelType));
            newVisualTypeComboBox.Header = "Type";
            newVisualTypeComboBox.SelectionChanged += newVisualTypeComboBox_SelectionChanged;

            newVisualPanel.HorizontalAlignment = Windows.UI.Xaml.HorizontalAlignment.Center;

            newVisualPanel.Children.Add(newVisualTitle);
            newVisualPanel.Children.Add(newVisualTypeComboBox);
            newVisualPanel.Children.Add(newVisualNameBox);
            
            newVisualPanel.Children.Add(newVisualCreateButton);

            newVisualPopup.Content = newVisualPanel;
            newVisualPopup.Placement = FlyoutPlacementMode.Bottom;

            newVisualCreateButton.IsEnabled = newVisualNameBox.Text.Length > 0 && newVisualTypeComboBox.SelectedItem != null;

            AddButton.Flyout = newVisualPopup;

            populateCurveIDComboBoxes();

            this.deleteItemMode = false;

            Flyout addItemFlyout = new Flyout();
            addItemFlyout.Placement = FlyoutPlacementMode.Right;

            StackPanel addItemFlyoutPanel = new StackPanel();
            addItemFlyoutPanel.Orientation = Windows.UI.Xaml.Controls.Orientation.Vertical;
            addItemFlyoutPanel.Width = 200;

            newItemCurveIDComboBox = new ComboBox();
            newItemCurveIDComboBox.Header = "Curve ID";
            newItemCurveIDComboBox.SelectionChanged += NewItemCurveIdComboBoxSelectionChanged;
            addItemFlyoutPanel.Children.Add(newItemCurveIDComboBox);

            createItemButton = new Button();
            createItemButton.HorizontalAlignment = HorizontalAlignment.Center;
            createItemButton.Click += CreateNewItemButton_Click;
            createItemButton.Content = "Create";

            addItemFlyoutPanel.Children.Add(createItemButton);

            addItemFlyout.Content = addItemFlyoutPanel;

            this.AddItemButton.Flyout = addItemFlyout;
            createItemButton.IsEnabled = false;
        }

        private void CreateNewItemButton_Click(object sender, RoutedEventArgs e)
        {
            ViewManager.Instance.addItem(((Panel)PageList.SelectedItem).Id, (int)newItemCurveIDComboBox.SelectedValue);
        }

        void newVisualTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            newVisualCreateButton.IsEnabled = newVisualNameBox.Text.Length > 0 && newVisualTypeComboBox.SelectedItem != null;
        }

        void NewItemCurveIdComboBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            createItemButton.IsEnabled = PageList.SelectedItem != null && newItemCurveIDComboBox.SelectedItem != null;
        }

        public async void populateCurveIDComboBoxes ()
        { 
            CurveInfo[] curveInfos = await JSONManager.getCurves(ViewManager.Instance.currentWellboreId);
            List<int> curveIds = new List<int>();

            foreach (CurveInfo curveInfo in curveInfos)
            {
                curveIds.Add(curveInfo.Id);
            }

            newItemCurveIDComboBox.ItemsSource = curveIds;
            newItemCurveIDComboBox.ItemsSource = curveIds;
        }

        void ItemListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (deleteItemMode && ItemList.SelectedItem != null)
            {
                showDeleteConfirmationDialog();
            }
        }

        /// <summary>
        /// Populates the page with content passed during navigation.  Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session.  The state will be null the first time a page is visited.</param>
        private void navigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
            // TODO: Assign a bindable group to Me.DefaultViewModel("Group")
            // TODO: Assign a collection of bindable items to Me.DefaultViewModel("Items")

            if (e.PageState == null)
            {
                // When this is a new page, select the first item automatically unless logical page
                // navigation is being used (see the logical page navigation #region below.)
                if (!this.UsingLogicalPageNavigation() && this.itemsViewSource.View != null)
                {
                    this.itemsViewSource.View.MoveCurrentToFirst();
                }
            }
            else
            {
                // Restore the previously saved state associated with this page
                if (e.PageState.ContainsKey("SelectedItem") && this.itemsViewSource.View != null)
                {
                    // TODO: Invoke Me.itemsViewSource.View.MoveCurrentTo() with the selected
                    //       item as specified by the value of pageState("SelectedItem")

                }
            }
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void navigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
            if (this.itemsViewSource.View != null)
            {
                // TODO: Derive a serializable navigation parameter and assign it to
                //       pageState("SelectedItem")

            }
        }

        #region Logical page navigation

        // The split page isdesigned so that when the Window does have enough space to show
        // both the list and the dteails, only one pane will be shown at at time.
        //
        // This is all implemented with a single physical page that can represent two logical
        // pages.  The code below achieves this goal without making the user aware of the
        // distinction.

        private const int MinimumWidthForSupportingTwoPanes = 768;

        /// <summary>
        /// Invoked to determine whether the page should act as one logical page or two.
        /// </summary>
        /// <returns>True if the window should show act as one logical page, false
        /// otherwise.</returns>
        private bool UsingLogicalPageNavigation()
        {
            return Window.Current.Bounds.Width < MinimumWidthForSupportingTwoPanes;
        }

        /// <summary>
        /// Invoked with the Window changes size
        /// </summary>
        /// <param name="sender">The current Window</param>
        /// <param name="e">Event data that describes the new size of the Window</param>
        private void Window_SizeChanged(object sender, Windows.UI.Core.WindowSizeChangedEventArgs e)
        {
            this.InvalidateVisualState();
        }

        private bool CanGoBack()
        {
            if (this.UsingLogicalPageNavigation() && this.PageList.SelectedItem != null)
            {
                return true;
            }
            else
            {
                return this.navigationHelper.CanGoBack();
            }
        }
        private void GoBack()
        {
            if (this.UsingLogicalPageNavigation() && this.PageList.SelectedItem != null)
            {
                // When logical page navigation is in effect and there's a selected item that
                // item's details are currently displayed.  Clearing the selection will return to
                // the item list.  From the user's point of view this is a logical backward
                // navigation.
                this.PageList.SelectedItem = null;
            }
            else
            {
                this.navigationHelper.GoBack();
            }
        }

        private void InvalidateVisualState()
        {
            var visualState = DetermineVisualState();
            VisualStateManager.GoToState(this, visualState, false);
            this.navigationHelper.GoBackCommand.RaiseCanExecuteChanged();
        }

        /// <summary>
        /// Invoked to determine the name of the visual state that corresponds to an application
        /// view state.
        /// </summary>
        /// <returns>The name of the desired visual state.  This is the same as the name of the
        /// view state except when there is a selected item in portrait and snapped views where
        /// this additional logical page is represented by adding a suffix of _Detail.</returns>
        private string DetermineVisualState()
        {
            if (!UsingLogicalPageNavigation())
                return "PrimaryView";

            // Update the back button's enabled state when the view state changes
            var logicalPageBack = this.UsingLogicalPageNavigation() && this.PageList.SelectedItem != null;

            return logicalPageBack ? "SinglePane_Detail" : "SinglePane";
        }

        #endregion

        #region NavigationHelper registration

        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// 
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="Common.NavigationHelper.LoadState"/>
        /// and <see cref="Common.NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedTo(e);
            ViewManager.Instance.Subscribe(this);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private void NewVisualCreate_Click(object sender, RoutedEventArgs e)
        {
            PanelType newVisualType = (PanelType)Enum.Parse(typeof(PanelType), (string)(newVisualTypeComboBox.SelectedValue));
            Debug.WriteLine("Clicked panel type " + newVisualType.ToString());
            ViewManager.Instance.addPanel(newVisualType, newVisualNameBox.Text); 
        }

        private void NameText_Changed(object sender, TextChangedEventArgs e)
        {
            newVisualCreateButton.IsEnabled = newVisualNameBox.Text.Length > 0 && newVisualTypeComboBox.SelectedItem != null;
        }

        public void OnCompleted()
        {
            throw new NotImplementedException();
        }

        public void OnError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void OnNext(View value)
        {
            PageList.ItemsSource = null;
            PageList.ItemsSource = value.Panels;
        }

        private void PanelListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Debug.WriteLine("Selecting a panel");
            currentPanel = (Panel)(PageList.SelectedItem);

            if (currentPanel != null)
            {
                NameTextBox.Text = currentPanel.Name;
                PanelTypeText.Text = currentPanel.Type.ToString();
                if (currentPanel.Visualizations != null && currentPanel.Visualizations.Length > 0)
                {
                    ItemList.ItemsSource = null;
                    ItemList.ItemsSource = currentPanel.Visualizations;
                    NoItemsText.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                }
                else
                {
                    ItemList.ItemsSource = null;
                    NoItemsText.Visibility = Windows.UI.Xaml.Visibility.Visible;
                }
            }
            else
            {

                ItemList.ItemsSource = null;
                PanelTypeText.Text = "No Panel Selected";
                NameTextBox.Text = "";
            }
        }

        private void DeleteItemButton_OnChecked(object sender, RoutedEventArgs e)
        {
            this.deleteItemMode = true;
        }

        private void DeleteItemButton_OnUnchecked(object sender, RoutedEventArgs e)
        {
            this.deleteItemMode = false;
        }

        private async void showDeleteConfirmationDialog()
        {
            deleteConfirmationDialog =
                        new MessageDialog("Are you sure you want to delete this item?");

            // Add commands and set their callbacks; both buttons use the same callback function instead of inline event handlers
            deleteConfirmationDialog.Commands.Add(new UICommand("Yes", new UICommandInvokedHandler(this.deleteCommandInvokedHandler)));
            deleteConfirmationDialog.Commands.Add(new UICommand("No", new UICommandInvokedHandler(this.cancelCommandInvokedHandler)));

            // Set the command that will be invoked by default
            deleteConfirmationDialog.DefaultCommandIndex = 0;

            deleteConfirmationDialog.CancelCommandIndex = 1;

            // Show the message dialog
            await deleteConfirmationDialog.ShowAsync();
        }

        private void deleteCommandInvokedHandler(IUICommand command)
        {
            ViewManager.Instance.deleteItem((Panel)PageList.SelectedItem, (VisualComponent)ItemList.SelectedItem);
            ItemList.SelectedItem = null;
        }

        private void cancelCommandInvokedHandler(IUICommand command)
        {
            ItemList.SelectedItem = null;
        }
    }
}
