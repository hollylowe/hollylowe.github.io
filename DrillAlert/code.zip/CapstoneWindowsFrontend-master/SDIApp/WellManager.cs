﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    public abstract class WellManager:IObservable<List<Well>>
    {
        protected static string userID = "00000000-0000-0000-0000-000000000001";

        protected List<Well> wells;
        protected List<IObserver<List<Well>>> observers;

        public virtual IDisposable Subscribe(IObserver<List<Well>> observer)
        {
            if (!observers.Contains(observer))
            {
                observers.Add(observer);
            }
            return new Unsubscriber(observers, observer);
        }

        protected void giveDataToObservers()
        {
            //observers should never be null
            foreach (IObserver<List<Well>> observer in observers)
            {
                observer.OnNext(wells);
            }
        }

        protected void giveErrorToObservers(Exception exc)
        {
            //observers should never be null
            foreach (IObserver<List<Well>> observer in observers)
            {
                observer.OnError(exc);
            }
        }

        //Copied from https://msdn.microsoft.com/en-us/library/dd783449%28v=vs.110%29.aspx
        protected class Unsubscriber : IDisposable
        {
            private List<IObserver<List<Well>>> _observers;
            private IObserver<List<Well>> _observer;

            public Unsubscriber(List<IObserver<List<Well>>> observers, IObserver<List<Well>> observer)
            {
                this._observers = observers;
                this._observer = observer;
            }

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }
        }
    }
}
