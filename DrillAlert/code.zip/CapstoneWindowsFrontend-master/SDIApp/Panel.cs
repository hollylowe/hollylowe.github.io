﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    public class Panel
    {
        [DataMember]
        public VisualComponent[] Visualizations { get; set; }
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int Pos { get; set; }
        [DataMember]
        public int XDim { get; set; }
        [DataMember]
        public int YDim { get; set; }
        [DataMember]
        public int ViewId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Type { get; set; }

        public PanelType panelType { set { } get { return (PanelType)Enum.Parse(typeof(PanelType), Type); } }
        
        public Panel(int id, int pos, int xDim, int yDim, int viewId, string name, PanelType type)
        {
            this.Id = id;
            this.Pos = pos;
            this.XDim = xDim;
            this.YDim = yDim;
            this.ViewId = viewId;
            this.Name = name;
            this.Type = type.ToString();
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
