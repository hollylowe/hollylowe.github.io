﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    class Curve
    {
        [DataMember]
        public int curveID { get; set; }
        [DataMember]
        public int wellboreID { get; set; }
        [DataMember]
        public CurvePoint[] data { get; set; }

        override public string ToString()
        {
            string curveString = "";
            curveString += "WellboreID: " + wellboreID + " ";
            curveString += "CurveID: " + curveID + " ";

            if (data != null)
            {
                curveString += "CurvePoints: ";
                foreach (CurvePoint curvePoint in data)
                {
                    curveString += curvePoint.ToString() + " ";
                }
            }

            return curveString;
        }

        public List<CurvePoint> getNewCurvePoints(Curve oldCurve)
        {
            List<CurvePoint> newPoints = new List<CurvePoint>();

            if (oldCurve != null)
            {
                foreach (CurvePoint point in data)
                {
                    if (!oldCurve.data.Contains(point))
                    {
                        newPoints.Add(point);
                    }
                }
            }

            return newPoints;
        }
    }
}
