﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using SDIApp.Common;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Diagnostics;
using Windows.ApplicationModel.Appointments.AppointmentsProvider;
using Windows.Media.Core;
using Windows.UI.Popups;

// The Group Detail Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234229

namespace SDIApp
{
    /// <summary>
    /// A page that displays an overview of a single group, including a preview of the items
    /// within the group.
    /// </summary>
    public sealed partial class WellSelectionPage : Page, IObserver<List<Well>>, IObserver<List<View>>
    {
        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();
        private bool deleteDashboardMode;
        private TextBox newDashboardNameBox;
        private MessageDialog deleteConfirmationDialog;
        private Button createDashboardButton;

        /// <summary>
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// NavigationHelper is used on each page to aid in navigation and 
        /// process lifetime management
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }

        public WellSelectionPage()
        {
            this.InitializeComponent();
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += navigationHelper_LoadState;
            this.deleteDashboardMode = false;

            Flyout addDashboardFlyout = new Flyout();
            addDashboardFlyout.Placement = FlyoutPlacementMode.Right;

            StackPanel addDashboardFlyoutPanel = new StackPanel();
            addDashboardFlyoutPanel.Orientation = Windows.UI.Xaml.Controls.Orientation.Vertical;
            addDashboardFlyoutPanel.Width = 200;

            newDashboardNameBox = new TextBox();
            newDashboardNameBox.Header = "Name:";

            createDashboardButton = new Button();
            createDashboardButton.HorizontalAlignment = HorizontalAlignment.Center;
            createDashboardButton.Click += CreateNewDashboardButton_Click;
            createDashboardButton.Content = "Create";

            addDashboardFlyoutPanel.Children.Add(newDashboardNameBox);
            addDashboardFlyoutPanel.Children.Add(createDashboardButton);

            addDashboardFlyout.Content = addDashboardFlyoutPanel;

            this.AddDashboardButton.Content = "+";
            this.AddDashboardButton.Flyout = addDashboardFlyout;
            this.newDashboardNameBox.TextChanged += NewDashboardNameBoxOnTextChanged;
            createDashboardButton.IsEnabled = false;
        }

        private void NewDashboardNameBoxOnTextChanged(object sender, TextChangedEventArgs textChangedEventArgs)
        {
            string currentText = newDashboardNameBox.Text;

            createDashboardButton.IsEnabled = true;

            if (currentText == "")
            {
                createDashboardButton.IsEnabled = false;
            }

            foreach (var item in ViewList.Items)
            {
                if (item.ToString() == currentText)
                {
                    createDashboardButton.IsEnabled = false;
                }
            }
        }

        /// <summary>
        /// Populates the page with content passed during navigation.  Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session.  The state will be null the first time a page is visited.</param>
        private void navigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
            // TODO: Assign a bindable group to this.DefaultViewModel["Group"]
            // TODO: Assign a collection of bindable items to this.DefaultViewModel["Items"]
        }

        #region NavigationHelper registration

        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// 
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="GridCS.Common.NavigationHelper.LoadState"/>
        /// and <see cref="GridCS.Common.NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedTo(e);
            AuthAvailableWellManager.Instance.Subscribe(this);
            ViewManager.Instance.Subscribe(this);
            DeleteDashboardButton.IsEnabled = false;
            AddDashboardButton.IsEnabled = false;
            this.deleteDashboardMode = false;

            WellboreList.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            ViewList.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Log Out clicked");
            if (this.Frame != null)
            {
                this.Frame.Navigate(typeof(MainPage));
            }
        }

        private void WellList_Tapped(object sender, TappedRoutedEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Well list tapped.");

            if (WellList.SelectedItem == null)
            {
                WellboreList.ItemsSource = null;
                WellboreList.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            }
            else
            {
                Well selectedWell = (Well)(WellList.SelectedItem);
                WellboreList.ItemsSource = selectedWell.wellBores;
                WellboreList.Visibility = Windows.UI.Xaml.Visibility.Visible;
                Debug.WriteLine("Selected well: " + selectedWell.ToString() + " with wellbores:");
                if (selectedWell.wellBores != null)
                {
                    foreach (Wellbore wellbore in selectedWell.wellBores)
                    {
                        Debug.WriteLine("   " + wellbore.name);
                    }

                    if (selectedWell.wellBores.Any())
                    {
                        NoWellboresText.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                    }
                    else {
                        NoWellboresText.Visibility = Windows.UI.Xaml.Visibility.Visible;
                    }
                }
                else
                {
                    Debug.WriteLine("   Wellbores are null");
                }

                WellboreList.SelectedItem = null;
                WellboreList_Tapped(sender, e);
            }
        }

        private void WellboreList_Tapped(object sender, TappedRoutedEventArgs e)
        {
            Debug.WriteLine("Wellbore list tapped.");
            List<View> wellboreViews = new List<View>();
            int wellboreId;
            if (WellboreList.SelectedItem == null)
            {
                wellboreId = -1;
                ViewList.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                DeleteDashboardButton.IsEnabled = false;
                AddDashboardButton.IsEnabled = false;
                this.deleteDashboardMode = false;
            }
            else
            {
                wellboreId = ((Wellbore)(WellboreList.SelectedItem)).id;
                ViewList.Visibility = Windows.UI.Xaml.Visibility.Visible;
                DeleteDashboardButton.IsEnabled = true;
                AddDashboardButton.IsEnabled = true;
            }
            ViewManager.Instance.changeWellboreID(wellboreId);
        }

        private void ViewList_Tapped(object sender, TappedRoutedEventArgs e)
        {
            if (this.deleteDashboardMode)
            {
                View selectedView = (View) ViewList.SelectedItem;
                if (selectedView != null)
                {
                    showDeleteConfirmationDialog(selectedView.Name);
                }
            }
            else if (this.Frame != null && ViewList.SelectedItem != null)
            {
                ViewManager.Instance.setCurrentView((View)(ViewList.SelectedItem));
                this.Frame.Navigate(typeof(Dashboard));
            }
        }

        private async void showDeleteConfirmationDialog(string viewName)
        {
            deleteConfirmationDialog =
                        new MessageDialog("Are you sure you want to delete " + viewName + "?");
            
            // Add commands and set their callbacks; both buttons use the same callback function instead of inline event handlers
            deleteConfirmationDialog.Commands.Add(new UICommand("Yes", new UICommandInvokedHandler(this.deleteCommandInvokedHandler)));
            deleteConfirmationDialog.Commands.Add(new UICommand("No", new UICommandInvokedHandler(this.cancelCommandInvokedHandler)));

            // Set the command that will be invoked by default
            deleteConfirmationDialog.DefaultCommandIndex = 0;

            deleteConfirmationDialog.CancelCommandIndex = 1;

            // Show the message dialog
            await deleteConfirmationDialog.ShowAsync();
        }

        private void deleteCommandInvokedHandler(IUICommand command)
        {
            ViewManager.Instance.deleteView((View)ViewList.SelectedItem);
            ViewList.SelectedItem = null;
        }

        private void cancelCommandInvokedHandler(IUICommand command)
        {
            ViewList.SelectedItem = null;
        }

        private void AlertsButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Alerts clicked");
            if (this.Frame != null)
            {
                this.Frame.Navigate(typeof(AlertsInbox));
            }
        }

        private void WellList_Loaded(object sender, RoutedEventArgs e)
        {
            if (WellList.Items == null || WellList.Items.Count <= 0)
            {
                Debug.WriteLine("Revealing NoWellsText");
                NoWellsText.Visibility = Windows.UI.Xaml.Visibility.Visible;
            }
            else
            {
                Debug.WriteLine("Hiding NoWellsText");
                NoWellsText.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            }
        }

        public void OnCompleted()
        {
            Debug.WriteLine("Completed");
        }

        public void OnError(Exception error)
        {
            Debug.WriteLine("Received an error");
            WellList.ItemsSource = new List<Well>();
            Debug.WriteLine("Revealing NoWellsText");
            NoWellsText.Visibility = Windows.UI.Xaml.Visibility.Visible;
        }

        public void OnNext(List<Well> value)
        {
            Debug.WriteLine("Hiding NoWellsText");
            NoWellsText.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            Debug.WriteLine("Updating well list");
            //Setting this ListView to null first seems to refresh the list more consistently
            WellList.ItemsSource = null;
            WellList.ItemsSource = value;
            Debug.WriteLine("Wells received by well list:");
            foreach (Well well in value)
            {
                Debug.WriteLine("   " + well.ToString());
            }
        }

        public void OnNext(List<View> value)
        {
            Debug.WriteLine("Updating view list");
            //Setting this ListView to null first seems to refresh the list more consistently
            ViewList.ItemsSource = null;
            ViewList.ItemsSource = value;
            Debug.WriteLine("Views received by view list:");
            foreach (View view in value)
            {
                Debug.WriteLine("   " + view.ToString());
            }

            if (value.Any())
            {
                NoViewsText.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
            }
            else
            {
                NoViewsText.Visibility = Windows.UI.Xaml.Visibility.Visible;
            }
        }

        private void DeleteDashboardButton_OnChecked(object sender, RoutedEventArgs e)
        {
            this.deleteDashboardMode = true;
        }

        private void CreateNewDashboardButton_Click(object sender, RoutedEventArgs e)
        {
            ViewManager.Instance.addView(newDashboardNameBox.Text);
            createDashboardButton.IsEnabled = false;
        }

        private void DeleteDashboardButton_OnUnchecked(object sender, RoutedEventArgs e)
        {
            this.deleteDashboardMode = false;
        }
    }
}
