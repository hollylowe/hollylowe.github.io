﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Windows.Web.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;
using Windows.Storage.Streams;
using System.Diagnostics;

namespace SDIApp
{
    class JSONManager
    {
        public static string BASE_URI = "https://drillalert.azurewebsites.net/api";
        //Must add /uid (?)
        //public static string BASE_WELL_URI = BASE_URI + "/permissions/windows";
        //Must add /wellboreID
        public static string BASE_VIEW_URI = BASE_URI + "/views";
        //Must add /wellboreID/curveID/0/0
        public static string BASE_CURVEPOINTS_URI = BASE_URI + "/curvepoints";
        //Must add /wellboreID
        public static string BASE_CURVE_URI = BASE_URI + "/curves";
        public static string BASE_ALERT_URI = BASE_URI + "/Alerts";
        public static string BASE_USER_URI = BASE_URI + "/Users";
        public static string BASE_ALERTS_HISTORY_URI = BASE_URI + "/AlertsHistory";
        public static string BASE_PUSH_URI = BASE_URI + "/Push/2";

        public static int userID;

        public static async Task<Well[]> getWells()
        {
            Well[] wells;
            Uri uri = new Uri(MainPage.loginURI);
            System.Diagnostics.Debug.WriteLine("Sending well uri: " + uri);

            try
            {
                wells = await getFromURI<Well>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
                return new Well[] { };
            }

            return wells;
        }

        public static async Task<View[]> getViews(int wellboreID)
        {
            View[] views;
            Uri uri = new Uri(BASE_VIEW_URI + "/" + wellboreID);
            System.Diagnostics.Debug.WriteLine("Sending view uri: " + uri);

            try
            {
                views = await getFromURI<View>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
                return new View[] { };
            }

            return views;
        }

        public static async Task<Curve[]> getCurvePoints(int wellboreID, int curveID)
        {
            Curve[] curves;
            Uri uri = new Uri(BASE_CURVEPOINTS_URI + "/" + curveID + "/" + wellboreID + "/0/0");
            System.Diagnostics.Debug.WriteLine("Sending curvepoints uri: " + uri);

            try
            {
                curves = await getFromURI<Curve>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
                return new Curve[] { };
            }

            return curves;
        }

        public static async Task<CurveInfo[]> getCurves(int wellboreID)
        {
            CurveInfo[] curves;
            Uri uri = new Uri(BASE_CURVE_URI + "/" + wellboreID);
            System.Diagnostics.Debug.WriteLine("Sending curve uri: " + uri);

            try
            {
                curves = await getFromURI<CurveInfo>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
                return new CurveInfo[] { };
            }

            return curves;
        }

        public static async Task<CurveInfo[]> getAllCurves()
        {
            CurveInfo[] curves;
            Uri uri = new Uri(BASE_CURVE_URI);
            System.Diagnostics.Debug.WriteLine("Sending all curves uri: " + uri);

            try
            {
                curves = await getFromURI<CurveInfo>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
                return new CurveInfo[] { };
            }

            return curves;
        }

        public static async Task<Alert[]> getAlerts()
        {
            Alert[] alerts;
            Uri uri = new Uri(BASE_ALERT_URI);
            System.Diagnostics.Debug.WriteLine("Sending alerts uri: " + uri);

            try
            {
                alerts = await getFromURI<Alert>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine("Alerts JSON error: " + exp.Message);
                return new Alert[] { };
            }

            return alerts;
        }

        public static async Task<Notification[]> getNotifications()
        {
            Notification[] notifications;
            Uri uri = new Uri(BASE_ALERTS_HISTORY_URI);
            System.Diagnostics.Debug.WriteLine("Sending alerts history uri: " + uri);

            try
            {
                notifications = await getFromURI<Notification>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine("Alerts history JSON error: " + exp.Message);
                return new Notification[] { };
            }

            return notifications;
        }

        public static async void getPush()
        {
            Uri uri = new Uri(BASE_PUSH_URI);
            System.Diagnostics.Debug.WriteLine("Sending push uri: " + uri);

            try
            {
                await getFromURI<Notification>(uri);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine("Alerts history JSON error: " + exp.Message);
            }
        }

        public static void postNotification(Notification notification)
        {
            Uri uri = new Uri(BASE_ALERTS_HISTORY_URI);
            System.Diagnostics.Debug.WriteLine("Post alerts history uri: " + uri);

            try
            {
                postToURI<Notification>(uri, notification);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine("Notification post error: " + exp.Message);
            }
        }

        public static void postView(View view)
        {
            Uri uri = new Uri(BASE_VIEW_URI);
            System.Diagnostics.Debug.WriteLine("Post view uri: " + uri);

            try
            {
                postToURI<View>(uri, view);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
            }
        }

        public static async void postAlert(Alert alert)
        {
            Uri uri = new Uri(BASE_ALERT_URI);
            System.Diagnostics.Debug.WriteLine("Post alert uri: " + uri);

            try
            {
                await postToURI<Alert>(uri, alert);
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp.Message);
            }
        }

        public static void deleteView(View view)
        {
            Uri uri = new Uri(BASE_VIEW_URI + "/" + view.Id);
            deleteToURI(uri);
        }

        public static async Task<Alert[]> deleteAlert(Alert alert)
        {
            Uri uri = new Uri(BASE_ALERT_URI + "/" + alert.Id);
            await deleteToURI(uri);
            return await getAlerts();
        }

        //Method created with help from https://social.msdn.microsoft.com/forums/windowsapps/en-us/db466fde-9056-4d01-b46d-cfa49c312c02/parsing-json-with-httpclient
        private static async Task<T[]> getFromURI<T>(Uri uri)
        {
            var client = MainPage.getClient();

            Debug.WriteLine("Awaiting on get...");

            IInputStream respStream = await client.GetInputStreamAsync(uri);
            Stream streamForSer = respStream.AsStreamForRead();
            T[] feed = new T[] { };

            Debug.WriteLine("Deserializing JSON");

            //TODO: Error catch serialization exceptions
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T[]));
                feed = (T[])ser.ReadObject(streamForSer);
            }
            catch (SerializationException serExc)
            {
                StreamReader reader = new StreamReader(streamForSer);
                string firstLine = reader.ReadLine();
                Debug.WriteLine("First line of JSON: " + firstLine);

                throw serExc;
            }

            return feed;
        }

        private static async Task postToURI<T>(Uri uri, T content)
        {
            var client = MainPage.getClient();

            Stream memoryStream = new MemoryStream();
            Debug.WriteLine("Serializing JSON of content " + content.ToString());

            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
                ser.WriteObject(memoryStream, content);
                memoryStream.Position = 0;
            }
            catch (SerializationException serExc)
            {
                Debug.WriteLine("Serialization exception on post");
                throw serExc;
            }

            StreamReader sr = new StreamReader(memoryStream);
            string contentString = sr.ReadToEnd();
            Debug.WriteLine("CONTENT STRING: " + contentString);
            HttpStringContent httpContent = new HttpStringContent(contentString);

            Debug.WriteLine("Awaiting on post...");
            var result = await client.PostAsync(uri, httpContent);
            Debug.WriteLine("POST RESULT: " + result.IsSuccessStatusCode.ToString());
        }

        private static async Task deleteToURI(Uri uri)
        {
            var client = MainPage.getClient();

            Debug.WriteLine("Awaiting on delete...");
            var result = await client.DeleteAsync(uri);
            Debug.WriteLine("DELETE RESULT: " + result.IsSuccessStatusCode.ToString());
        }

        public static async void getUserId()
        {
            Uri uri = new Uri(BASE_USER_URI);
            HttpClient client = MainPage.getClient();

            IInputStream respStream = await client.GetInputStreamAsync(uri);
            Stream streamForSer = respStream.AsStreamForRead();

            StreamReader sr = new StreamReader(streamForSer);
            string userIDString = sr.ReadToEnd();
            userID = Convert.ToInt32(userIDString);
        }
    }
}
