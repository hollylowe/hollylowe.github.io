﻿using SDIApp.Common;
using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Networking.PushNotifications;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using System.Diagnostics;
using Windows.Web.Http;
using Windows.System.Profile;
using Windows.Web.Http.Headers;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234237

namespace SDIApp
{
    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private static string LOGIN_URI = "https://drillalert.azurewebsites.net/api/permissions/windows/";

        private static HttpClient client = new HttpClient();
        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();
        private String deviceID;
        private PushNotificationChannel channel = null;
        public static String loginURI;

        public static int userID = 1;

        public static HttpClient getClient()
        {
            return client;
        }

        /// <summary>
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// NavigationHelper is used on each page to aid in navigation and 
        /// process lifetime management
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }


        public MainPage()
        {
            Debug.WriteLine("Initializing");
            this.InitializeComponent();
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += navigationHelper_LoadState;
            this.navigationHelper.SaveState += navigationHelper_SaveState;
        }

        private string GetHardwareId()
        {
            var token = HardwareIdentification.GetPackageSpecificToken(null);
            var hardwareId = token.Id;
            var dataReader = Windows.Storage.Streams.DataReader.FromBuffer(hardwareId);

            byte[] bytes = new byte[hardwareId.Length];
            dataReader.ReadBytes(bytes);

            return BitConverter.ToString(bytes);
        }

        /// <summary>
        /// Populates the page with content passed during navigation. Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session. The state will be null the first time a page is visited.</param>
        private void navigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void navigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
        }

        #region NavigationHelper registration

        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// 
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="GridCS.Common.NavigationHelper.LoadState"/>
        /// and <see cref="GridCS.Common.NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            Debug.WriteLine("Navigated To");
            navigationHelper.OnNavigatedTo(e);

            this.deviceID = this.GetHardwareId();
            try
            {
                channel = await PushNotificationChannelManager.CreatePushNotificationChannelForApplicationAsync();
                byte[] bytes = Encoding.UTF8.GetBytes(channel.Uri.ToString());
                string base64 = Convert.ToBase64String(bytes);
                base64 = Uri.EscapeUriString(base64);
                String channelURI = Uri.EscapeUriString(base64);
                Debug.WriteLine("Channel URI: " + channel.Uri.ToString());
                Debug.WriteLine("Escaped URI: " + Uri.EscapeUriString(channel.Uri.ToString()));
                Debug.WriteLine("base64 URI: " + channelURI);

                loginURI = LOGIN_URI + channelURI;
                this.loggedIn = false;
                client = new HttpClient();

                NoConnectionTextBlock.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                LoginWebView.Visibility = Windows.UI.Xaml.Visibility.Visible;
                this.loggedIn = false;

                Debug.WriteLine("Creating URI");
                Uri loginPage = new Uri(loginURI);

                Debug.WriteLine("Navigating to URI: " + loginPage.ToString());
                LoginWebView.Navigate(loginPage);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("No Channel created");
            }
        }

        private string StringToHex(string hexstring)
        {
            var sb = new StringBuilder();
            foreach (char t in hexstring)
                sb.Append(Convert.ToInt32(t).ToString("x") + "");
            return sb.ToString();
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private bool loggedIn = false;

        private async void PageLoadComplete(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            if (args.IsSuccess)
            {
                Debug.WriteLine("Loaded page");
                Debug.WriteLine(args.Uri);

                NoConnectionTextBlock.Visibility = Windows.UI.Xaml.Visibility.Collapsed;

                if (args.Uri.Equals(loginURI))
                {
                    loggedIn = true;
                    LoginWebView.Visibility = Windows.UI.Xaml.Visibility.Collapsed;
                }

                if (loggedIn)
                {
                    HttpResponseMessage myResponse = (await client.GetAsync(args.Uri));
                    Debug.WriteLine("printing header:");
                    Debug.WriteLine(myResponse.Headers);
                    JSONManager.getUserId();
                    if (this.Frame != null)
                    {
                        this.Frame.Navigate(typeof(WellSelectionPage));
                    }
                }
            }
            else
            {
                Debug.WriteLine("Could not reach server. Navigating to URI");
                NoConnectionTextBlock.Visibility = Windows.UI.Xaml.Visibility.Visible;
                Uri loginPage = new Uri(loginURI);
                LoginWebView.Navigate(loginPage);
            }
        }

        private class FirstFieldComparer : IEqualityComparer<KeyValuePair<string, string>>
        {

            public bool Equals(KeyValuePair<string, string> x, KeyValuePair<string, string> y)
            {
                return x.Key.Equals(y.Key);
            }

            public int GetHashCode(KeyValuePair<string, string> obj)
            {
                throw new NotImplementedException();
            }
        }
    }
}