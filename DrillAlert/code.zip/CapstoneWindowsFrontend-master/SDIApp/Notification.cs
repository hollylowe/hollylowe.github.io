﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace SDIApp
{
    [DataContract]
    public class Notification
    {
        public enum Severity { Information, Warning, Critical };

        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public string NotificationSeverity { get; set; }

        public Severity severity { set { } get { return (Severity)Enum.Parse(typeof(Severity), NotificationSeverity); } }
        [DataMember(Name = "NotificationDate")]
        private string FormattedNotificationDate { get; set; }
        [IgnoreDataMember]
        public DateTime date
        {
            get
            {
                return DateTime.ParseExact(FormattedNotificationDate, "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff",
                  CultureInfo.InvariantCulture);
            }
            set { FormattedNotificationDate = value.ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff"); }

        }
        [DataMember]
        public int TriggeringAlert { get; set; }
        [DataMember]
        public bool Acknowledged { get; set; }

        /*
         * Create an alert with the specified values. The curve id specifies the parameter being measured, on the specified wellbore.
         * If rising is true, the alert will trigger when the value passes above the threshold, otherwise it will trigger when
         * the value passes below the threshold.
         */
        public Notification(string message, Severity severity, String date, int alertID, bool acknowledged)
        {
            this.Message = message;
            this.NotificationSeverity = severity.ToString();
            this.FormattedNotificationDate = date;
            this.TriggeringAlert = alertID;
            this.Acknowledged = acknowledged;
        }

        public override string ToString()
        {
            return "AlertID: " + TriggeringAlert + " date: " + FormattedNotificationDate + " message: " + Message;
        }

        public bool equals(int alertID, string date, string message, string severity)
        {
            if (this.TriggeringAlert == alertID && this.FormattedNotificationDate.Equals(date) &&
                this.Message.Equals(message) && this.NotificationSeverity.Equals(severity))
            {
                return true;
            }
            return false;
        }
    }
}
