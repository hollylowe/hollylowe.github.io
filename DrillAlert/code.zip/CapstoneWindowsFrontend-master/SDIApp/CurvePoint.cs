﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    class CurvePoint
    {
        [DataMember]
        public float value { get; set; }
        [DataMember]
        public string time { get; set; }

        override public string ToString()
        {
            return "(" + value + ", " + time + ")";
        }
    }
}
