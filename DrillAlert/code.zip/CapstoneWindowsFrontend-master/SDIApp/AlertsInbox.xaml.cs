﻿using SDIApp.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Basic Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234237

namespace SDIApp
{
    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class AlertsInbox : Page
    {

        private NavigationHelper navigationHelper;
        private ObservableDictionary defaultViewModel = new ObservableDictionary();
        private Notification[] notifications;

        /// <summary>
        /// This can be changed to a strongly typed view model.
        /// </summary>
        public ObservableDictionary DefaultViewModel
        {
            get { return this.defaultViewModel; }
        }

        /// <summary>
        /// NavigationHelper is used on each page to aid in navigation and 
        /// process lifetime management
        /// </summary>
        public NavigationHelper NavigationHelper
        {
            get { return this.navigationHelper; }
        }


        public AlertsInbox()
        {
            this.InitializeComponent();
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += navigationHelper_LoadState;
            this.navigationHelper.SaveState += navigationHelper_SaveState;
        }

        /// <summary>
        /// Populates the page with content passed during navigation. Any saved state is also
        /// provided when recreating a page from a prior session.
        /// </summary>
        /// <param name="sender">
        /// The source of the event; typically <see cref="NavigationHelper"/>
        /// </param>
        /// <param name="e">Event data that provides both the navigation parameter passed to
        /// <see cref="Frame.Navigate(Type, Object)"/> when this page was initially requested and
        /// a dictionary of state preserved by this page during an earlier
        /// session. The state will be null the first time a page is visited.</param>
        private void navigationHelper_LoadState(object sender, LoadStateEventArgs e)
        {
        }

        /// <summary>
        /// Preserves state associated with this page in case the application is suspended or the
        /// page is discarded from the navigation cache.  Values must conform to the serialization
        /// requirements of <see cref="SuspensionManager.SessionState"/>.
        /// </summary>
        /// <param name="sender">The source of the event; typically <see cref="NavigationHelper"/></param>
        /// <param name="e">Event data that provides an empty dictionary to be populated with
        /// serializable state.</param>
        private void navigationHelper_SaveState(object sender, SaveStateEventArgs e)
        {
        }

        #region NavigationHelper registration

        /// The methods provided in this section are simply used to allow
        /// NavigationHelper to respond to the page's navigation methods.
        /// 
        /// Page specific logic should be placed in event handlers for the  
        /// <see cref="GridCS.Common.NavigationHelper.LoadState"/>
        /// and <see cref="GridCS.Common.NavigationHelper.SaveState"/>.
        /// The navigation parameter is available in the LoadState method 
        /// in addition to page state preserved during an earlier session.

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedTo(e);

            disableButtons();
            getAlertsHistory();
        }

        protected void disableButtons()
        {
            CriticalAcceptButton.IsEnabled = false;
            WarningAcceptButton.IsEnabled = false;
            InformationAcceptButton.IsEnabled = false;
        }

        protected async void getAlertsHistory()
        {
            this.notifications = await JSONManager.getNotifications();

            if (notifications == null)
            {
                notifications = new Notification[] { };
            }

            populateListboxes();
        }

        protected void populateListboxes()
        {
            foreach (Notification notification in notifications)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = notification.ToString();

                switch (notification.NotificationSeverity)
                {
                    case "2":
                        if (notification.Acknowledged)
                        {
                            CriticalReadListbox.Items.Add(item);
                        }
                        else
                        {
                            CriticalUnreadListbox.Items.Add(item);
                        }
                        break;
                    case "1":
                        if (notification.Acknowledged)
                        {
                            WarningReadListbox.Items.Add(item);
                        }
                        else
                        {
                            WarningUnreadListbox.Items.Add(item);
                        }
                        break;
                    case "0":
                        if (notification.Acknowledged)
                        {
                            InformationalReadListbox.Items.Add(item);
                        }
                        else
                        {
                            InformationalUnreadListbox.Items.Add(item);
                        }
                        break;
                }
            }
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            navigationHelper.OnNavigatedFrom(e);
        }

        #endregion

        private void pageTitle_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void ManageAlerts(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(ManageAlerts));
        }

        private void AlertsInboxBack(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(WellSelectionPage));
        }

        private void CriticalAcceptButton_click(object sender, RoutedEventArgs e)
        {
            ListBoxItem selected = (ListBoxItem)CriticalUnreadListbox.SelectedValue;
            int alertID = parseAlertID(selected.Content.ToString());
            string date = parseDate(selected.Content.ToString());
            string message = parseMessage(selected.Content.ToString());
            Notification notification = null;

            foreach (Notification n in notifications)
            {
                if (n.equals(alertID, date, message, "2"))
                {
                    notification = n;
                    break;
                }
            }

            CriticalUnreadListbox.Items.Remove(selected);
            CriticalReadListbox.Items.Add(selected);
            CriticalAcceptButton.IsEnabled = false;

            JSONManager.postNotification(notification);
        }

        private void WarningAcceptButton_click(object sender, RoutedEventArgs e)
        {
            ListBoxItem selected = (ListBoxItem)WarningUnreadListbox.SelectedValue;
            int alertID = parseAlertID(selected.Content.ToString());
            string date = parseDate(selected.Content.ToString());
            string message = parseMessage(selected.Content.ToString());
            Notification notification = null;

            foreach (Notification n in notifications)
            {
                if (n.equals(alertID, date, message, "1"))
                {
                    notification = n;
                    break;
                }
            }

            WarningUnreadListbox.Items.Remove(selected);
            WarningReadListbox.Items.Add(selected);
            WarningAcceptButton.IsEnabled = false;

            JSONManager.postNotification(notification);
        }

        private void InformationAcceptButton_click(object sender, RoutedEventArgs e)
        {
            ListBoxItem selected = (ListBoxItem)InformationalUnreadListbox.SelectedValue;
            int alertID = parseAlertID(selected.Content.ToString());
            string date = parseDate(selected.Content.ToString());
            string message = parseMessage(selected.Content.ToString());
            Notification notification = null;

            foreach (Notification n in notifications)
            {
                if (n.equals(alertID, date, message, "0"))
                {
                    notification = n;
                    break;
                }
            }

            InformationalUnreadListbox.Items.Remove(selected);
            InformationalReadListbox.Items.Add(selected);
            InformationAcceptButton.IsEnabled = false;

            JSONManager.postNotification(notification);
        }

        private int parseAlertID(String notification)
        {
            char[] space = { ' ' };
            string[] words = notification.Split(space);
            return Convert.ToInt32(words[1]);
        }

        private string parseDate(String notification)
        {
            char[] space = { ' ' };
            string[] words = notification.Split(space);
            return words[3];
        }

        private string parseMessage(String notification)
        {
            char[] space = { ' ' };
            string[] words = notification.Split(space);
            String message = "";
            for (int i = 5; i < words.Length; i++)
            {
                message = message + words[i] + " ";
            }
            return message.Trim();
        }

        private void CriticalUnreadSelected(object sender, SelectionChangedEventArgs e)
        {
            CriticalAcceptButton.IsEnabled = true;
        }

        private void WarningUnreadSelected(object sender, SelectionChangedEventArgs e)
        {
            WarningAcceptButton.IsEnabled = true;
        }

        private void InformationalUnreadSelected(object sender, SelectionChangedEventArgs e)
        {
            InformationAcceptButton.IsEnabled = true;
        }
    }
}
