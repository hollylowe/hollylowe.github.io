﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace SDIApp
{
    [DataContract]
    public class Wellbore
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int wellId { get; set; }
        [DataMember]
        public string name { get; set; }
        

        public override string ToString()
        {
            return name;
        }
    }
}
