﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace SDIApp
{
    public class AutoUpdateWebView
    {
        private static string BASE_PANEL_URI = "ms-appx-web:///assets/index.html";
        private static int TIMER_INTERVAL_S = 2;
        private static int TITLE_FONT_SIZE = 36;

        private static int WEB_VIEW_HEIGHT = 550;
        private static int WEB_VIEW_WIDTH = 1000;

        private static string TIME_STAMP_LABEL = "Last updated: ";
        private static string TIME_STAMP_NOW_LABEL = "Now";
        private static string TIME_STAMP_1SECOND_LABEL = " second ago";
        private static string TIME_STAMP_SECONDS_LABEL = " seconds ago";
        private static string TIME_STAMP_LOADING_LABEL = "Loading...";
        private static string TIME_STAMP_NO_CURVE_LABEL = "No curve selected";
        private static string TIME_STAMP_LABEL_NO_ITEMS_LABEL = "No items to display";
        private static string TIME_STAMP_ERROR_LABEL = "Error reading data";
        private static int TIME_STAMP_FONT_SIZE = 24;
        private static int TIME_STAMP_TIMER_INTERVAL_S = 1;

        private Curve currentCurve;
        private DispatcherTimer timer;
        private Panel panel;
        private StackPanel stackPanel;
        private TextBlock title;
        private TextBlock timeStamp;
        private WebView webView;

        private DispatcherTimer timeStampTimer;
        private int timeStampSeconds;

        public AutoUpdateWebView(Panel panel)
        {
            this.panel = panel;

            title = new TextBlock();
            title.Text = panel.Name;
            title.FontSize = TITLE_FONT_SIZE;
            title.HorizontalAlignment = HorizontalAlignment.Center;

            timeStampSeconds = 0;

            timeStamp = new TextBlock();
            timeStamp.Text = TIME_STAMP_LOADING_LABEL;
            timeStamp.FontSize = TIME_STAMP_FONT_SIZE;
            timeStamp.HorizontalAlignment = HorizontalAlignment.Center;

            timer = new DispatcherTimer();
            timer.Interval = System.TimeSpan.FromSeconds(TIMER_INTERVAL_S);

            timeStampTimer = new DispatcherTimer();
            timeStampTimer.Interval = System.TimeSpan.FromSeconds(TIME_STAMP_TIMER_INTERVAL_S);
            timeStampTimer.Tick += timeStampTimer_Tick;

            webView = new WebView();
            webView.Height = WEB_VIEW_HEIGHT;
            webView.Width = WEB_VIEW_WIDTH;

            stackPanel = new StackPanel();
            stackPanel.Orientation = Orientation.Vertical;
            stackPanel.HorizontalAlignment = HorizontalAlignment.Center;

            if (panel.Visualizations != null && panel.Visualizations.Length > 0)
            {
                switch (panel.panelType)
                {
                    case PanelType.Plot:
                        webView.NavigationCompleted += Plot_NavigationCompleted;
                        break;
                    case PanelType.Canvas:
                        Debug.WriteLine("Adding load listener to Canvas");
                        webView.NavigationCompleted += Canvas_NavigationCompleted;
                        break;
                }
            }
            else
            {
                timeStamp.Text = TIME_STAMP_LABEL_NO_ITEMS_LABEL;
            }

            webView.Navigate(new Uri(BASE_PANEL_URI));

            stackPanel.Children.Add(title);
            stackPanel.Children.Add(timeStamp);
            stackPanel.Children.Add(webView);
        }

        void timeStampTimer_Tick(object sender, object e)
        {
            timeStampSeconds += TIME_STAMP_TIMER_INTERVAL_S;

            if (timeStampSeconds <= 0) {
                timeStamp.Text = TIME_STAMP_LABEL + TIME_STAMP_NOW_LABEL;
            }
            else if (timeStampSeconds == 1)
            {
                timeStamp.Text = TIME_STAMP_LABEL + timeStampSeconds + TIME_STAMP_1SECOND_LABEL;
            }
            else
            {
                timeStamp.Text = TIME_STAMP_LABEL + timeStampSeconds + TIME_STAMP_SECONDS_LABEL;
            }
        }

        private async void Plot_NavigationCompleted(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            Debug.WriteLine("Invoking JavaScript...");

            if (panel.Visualizations[0].CurveIds == null || panel.Visualizations[0].CurveIds.Length == 0)
            {
                Debug.WriteLine("Plot has no curve IDs");
                timeStamp.Text = TIME_STAMP_NO_CURVE_LABEL;
                return;
            }

            currentCurve =await CurveManager.Instance.getCurve(ViewManager.Instance.currentWellboreId,
                            panel.Visualizations[0].CurveIds[0]);
            string dataString = "";
            string timeString = "";

            
            List<CurvePoint> initCurvePoints = new List<CurvePoint>();
            initCurvePoints.AddRange(currentCurve.data);
            initCurvePoints.Sort(new CurvePointComparer());

            foreach (CurvePoint point in currentCurve.data)
            {
                dataString += point.value + ", ";
                timeString += point.time + ", ";
            }
            dataString.Remove(dataString.Length - ", ".Length);
            timeString.Remove(timeString.Length - ", ".Length);

            try
            {
                await sender.InvokeScriptAsync("eval", new string[] { "master.init(config = {yMax : 60, xMax : 30, data : [" + dataString + "], idata: [" + timeString + "], width : 500, height : 300, id : " + panel.Id + "})" });
                Debug.WriteLine("JavaScript call successful!");
            }
            catch (Exception exc)
            {
                Debug.WriteLine("JavaScript call failed.");
                Debug.WriteLine("Exception message: " + exc.Message);
                timeStamp.Text = TIME_STAMP_ERROR_LABEL;
            }

            timer.Tick += plotTimerTicker;
            timer.Start();
            timeStampTimer.Start();
        }

        private async void Canvas_NavigationCompleted(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            Debug.WriteLine("Invoking JavaScript...");

            if (panel.Visualizations[0].CurveIds == null || panel.Visualizations[0].CurveIds.Length == 0)
            {
                Debug.WriteLine("Canvas has no curve IDs");
                timeStamp.Text = TIME_STAMP_NO_CURVE_LABEL;
                return;
            }

            currentCurve = await CurveManager.Instance.getCurve(ViewManager.Instance.currentWellboreId, panel.Visualizations[0].CurveIds[0]);
            try
            {
                await sender.InvokeScriptAsync("eval", new string[] { "masterGauge.init(config={size: 300,clipWidth: 300,clipHeight: 300,ringWidth: 60,maxValue: 30,transitionMs: 2000,id: " + panel.Id + "})" });
                Debug.WriteLine("JavaScript call successful!");
            }
            catch (Exception exc)
            {
                Debug.WriteLine("JavaScript call failed.");
                Debug.WriteLine("Exception message: " + exc.Message);
                timeStamp.Text = TIME_STAMP_ERROR_LABEL;
            }

            timer.Tick += canvasTimerTicker;
            timer.Start();
            timeStampTimer.Start();
        }

        private async void plotTimerTicker(object sender, object e)
        {
            List<CurvePoint> newPoints = new List<CurvePoint>();

            Curve newCurve = await CurveManager.Instance.getCurve(ViewManager.Instance.currentWellboreId, panel.Visualizations[0].CurveIds[0]);
            newPoints = newCurve.getNewCurvePoints(currentCurve);

            foreach (CurvePoint point in newPoints)
            {
                await webView.InvokeScriptAsync("eval", new string[] { "master.tick(xDataPoint=" + point.value + ", yDataPoint=" + point.time + ", id=" + panel.Id + ")" });
            }

            if (newPoints.Count > 0)
            {
                timeStampSeconds = 0;
            }
        }

        private async void canvasTimerTicker(object sender, object e)
        {
            Debug.WriteLine("Canvas timer ticker");
            List<CurvePoint> newPoints = new List<CurvePoint>();

            Curve newCurve = await CurveManager.Instance.getCurve(ViewManager.Instance.currentWellboreId, panel.Visualizations[0].CurveIds[0]);
            newPoints = newCurve.getNewCurvePoints(currentCurve);

            foreach (CurvePoint point in newPoints)
            {
                Debug.WriteLine("Gauge data string: " + Math.Floor(point.value));
                await webView.InvokeScriptAsync("eval", new string[] { "masterGauge.update(val=" + Math.Floor(point.value) + ", id=" + panel.Id + ")" });
            }

            if (newPoints.Count > 0)
            {
                timeStampSeconds = 0;
            }
        }

        public StackPanel getDisplayPanel()
        {
            return stackPanel;
        }

        //TimeStamp timer will continue since it needs to track how long since last update
        public void stop()
        {
            timer.Stop();
            timeStampTimer.Stop();
            timeStamp.Text = TIME_STAMP_LOADING_LABEL;
        }

        //TimeStamp timer should already be running since it needs to track how long since last update
        public void start()
        {
            timer.Start();
            timeStamp.Text = TIME_STAMP_LOADING_LABEL;
            timeStampTimer.Start();
        }

        private class CurvePointComparer : IComparer<CurvePoint>
        {
            public int Compare(CurvePoint x, CurvePoint y)
            {
                return x.time.CompareTo(y.time);
            }
        }
    }
}
