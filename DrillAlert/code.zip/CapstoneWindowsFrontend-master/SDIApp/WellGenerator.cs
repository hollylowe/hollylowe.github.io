﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    class WellGenerator
    {
        public static List<Well> generateWells(int numWells = 2)
        {
            List<Well> wells = new List<Well>();
            int currentWellboreId = 0;
            int currentCurveId = 0;

            for (int i = 0; i < numWells; i++)
            {
                Well currentWell = generateWell(i, currentWellboreId, currentCurveId);
                wells.Add(currentWell);
                currentWellboreId += currentWell.wellBores.Length;
                foreach (Wellbore wellbore in currentWell.wellBores)
                {
                    //currentCurveId += wellbore.curves.Count;
                }
            }

            return wells;
        }

        public static Well generateWell(int wellId, int currentWellboreId, int currentCurveId)
        {
            Well well = new Well();
            well.wellId = wellId;
            well.name = "Well #" + wellId;
            List<Wellbore> wellbores = new List<Wellbore>();

            for (int i = 0; i < 2; i++)
            {
                wellbores.Add(generateWellbore(currentWellboreId + i, currentCurveId));
            }

            well.wellBores = wellbores.ToArray();
            return well;
        }

        public static Wellbore generateWellbore (int wellboreId, int currentCurveId)
        {
            Wellbore wellbore = new Wellbore();

            wellbore.id = wellboreId;
            wellbore.name = "Wellbore #" + wellboreId;

            List<Curve> curves = new List<Curve>();
            curves.Add(generateCurve(currentCurveId, wellboreId));

            //wellbore.curves = curves;

            return wellbore;
        }

        public static Curve generateCurve(int curveId, int wellboreId)
        {
            Curve curve = new Curve();
            curve.curveID = curveId;
            curve.wellboreID = wellboreId;
            curve.data = generateCurvePoints(3).ToArray();
            return curve;
        }

        public static List<CurvePoint> generateCurvePoints(int num = 1)
        {
            List<CurvePoint> points = new List<CurvePoint>();
            Random randomGen = new Random();
            int time = 0;

            for (int i = 0; i < num; i++)
            {
                CurvePoint point = new CurvePoint();
                point.value = (float)(randomGen.NextDouble());
                point.time = time.ToString();
                points.Add(point);
                time += randomGen.Next();
            }

            return points;
        }
    }
}
