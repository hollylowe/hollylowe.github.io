﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    class AuthAvailableWellManager : WellManager
    {
        private static bool refreshRunning = false;
        protected static AuthAvailableWellManager instance;

        protected AuthAvailableWellManager()
        {
            observers = new List<IObserver<List<Well>>>();
            wells = new List<Well>();
            refreshRunning = false;
            refreshWells();
        }

        public static AuthAvailableWellManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new AuthAvailableWellManager();
                }
                return instance;
            }
        }

        public async void refreshWells()
        {
            if (!refreshRunning)
            {
                refreshRunning = true;
                wells = new List<Well>();

                Well[] newWells = await JSONManager.getWells();

                if (newWells != null)
                {
                    wells.AddRange(newWells);
                    Debug.WriteLine("Got wells.");
                    foreach (Well well in newWells)
                    {
                        Debug.WriteLine("New well: " + well.ToString());
                    }
                    giveDataToObservers();
                }
                else
                {
                    Debug.WriteLine("No new wells.");
                    giveErrorToObservers(new Exception("Cannot connect to well data."));
                }
                refreshRunning = false;
            }
        }

        public override IDisposable Subscribe(IObserver<List<Well>> observer)
        {
            
            if (!observers.Contains(observer))
            {
                observers.Add(observer);
            }
            refreshWells();
            return new Unsubscriber(observers, observer);
        }
    }
}
