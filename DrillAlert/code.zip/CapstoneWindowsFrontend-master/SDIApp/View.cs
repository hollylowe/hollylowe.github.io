﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    public class View
    {
        [DataMember]
        public Panel[] Panels { get; set; }
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int WellboreId { get; set; }
        [DataMember]
        public int UserId { get; set; }

        public View(Panel[] panels, int wellboreId, string name)
        {
            this.Panels = panels;
            this.WellboreId = wellboreId;
            this.Name = name;
            this.UserId = JSONManager.userID;
            this.Panels = new Panel[] {};
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
