﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    class TestJSONManager
    {
        //Returns 1 fake well with 1 fake wellbore without accessing the server 
        public static Well[] getWells(string userID)
        {
            List<Well> wells = new List<Well>();
            List<Wellbore> wellbores = new List<Wellbore>();

            Wellbore wellbore = new Wellbore();
            wellbore.id = 0;
            wellbore.name = "Test Wellbore";
            wellbore.wellId = 0;
            wellbores.Add(wellbore);

            Well well = new Well();
            well.name = "Test Well";
            well.location = "Test Location";
            well.wellId = 0;
            well.wellBores = wellbores.ToArray();
            wells.Add(well);

            return wells.ToArray();
        }

        //Returns 1 fake view with 1 fake panel without accessing the server
        public static View[] getViews(int wellboreID)
        {
            List<View> views = new List<View>();

            View view = new View(new Panel[] { new Panel(0, 0, 100, 100, 0, "Test Panel", PanelType.Plot) }, 0, "Test Dashboard");
            views.Add(view);

            return views.ToArray();
        }

        //Returns 1 fake curve with the give wellbore and curve IDs and 1 fake curve point as data without accessing the server
        public static Curve[] getCurvePoints(int wellboreID, int curveID)
        {
            List<Curve> curves = new List<Curve>();
            List<CurvePoint> curvePoints = new List<CurvePoint>();

            CurvePoint curvePoint = new CurvePoint();
            curvePoint.time = "0";
            curvePoint.value = 0;
            curvePoints.Add(curvePoint);

            Curve curve = new Curve();
            curve.curveID = curveID;
            curve.wellboreID = wellboreID;
            curve.data = curvePoints.ToArray();
            curves.Add(curve);

            return curves.ToArray();
        }

        //Returns 1 fake CurveInfo without accessing the server
        public static CurveInfo[] getCurves(int wellboreID)
        {
            List<CurveInfo> curveInfos = new List<CurveInfo>();

            CurveInfo curveInfo = new CurveInfo("Test Curve Info", "Test Tool Type", "in");
            curveInfos.Add(curveInfo);

            return curveInfos.ToArray();
        }

        //Returns 1 fake Alert without accessing the server
        public static Alert[] getAlerts()
        {
            List<Alert> alerts = new List<Alert>();

            Alert alert = new Alert("Test Alert", 0, true, 0, Alert.Severity.Warning, 10);
            alerts.Add(alert);

            return alerts.ToArray();
        }
    }
}
