﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    public class CurveInfo
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public String Name { get; set; }
        [DataMember]
        public String ToolType { get; set; }
        [DataMember]
        public String Units { get; set; }

        public CurveInfo(String name, String toolType, String units)
        {
            this.Name = name;
            this.ToolType = toolType;
            this.Units = units;
        }

        public override String ToString()
        {
            return "Name: " + this.Name + " Id: " + this.Id + " ToolType: " + this.ToolType + " Units: " + this.Units;
        }
    }
}
