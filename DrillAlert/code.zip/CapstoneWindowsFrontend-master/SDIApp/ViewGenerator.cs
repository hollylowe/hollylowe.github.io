﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    class ViewGenerator
    {
        public static List<View> generateViews(List<Well> wells, int num = 4)
        {
            List<View> views = new List<View>();

            for (int i = 0; i < num; i++)
            {
                views.Add(generateView(wells));
            }

            return views;
        }

        public static View generateView(List<Well> wells) {
            return new View(null, 0, "");//(wellbore, jsFile, viewType, name);
        }
    }
}
