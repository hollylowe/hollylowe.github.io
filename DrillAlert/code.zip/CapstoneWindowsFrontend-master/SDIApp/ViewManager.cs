﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Automation.Peers;

namespace SDIApp
{
    public class ViewManager:IObservable<List<View>>, IObservable<View>
    {
        public int currentWellboreId = -1;
        public View currentView;
        protected List<IObserver<List<View>>> listViewObservers;
        protected List<IObserver<View>> viewObservers;

        protected static ViewManager instance;

        protected ViewManager() {
            listViewObservers = new List<IObserver<List<View>>>();
            viewObservers = new List<IObserver<View>>();
            refreshViews();
        }

        public static ViewManager Instance
        {
            get 
            {
                if (instance == null)
                {
                    instance = new ViewManager();
                }
                return instance;
            }
        }

        public void changeWellboreID(int newWellboreID)
        {
            currentWellboreId = newWellboreID;
            refreshViews();
        }

        public async void refreshViews()
        {
            List<View> refreshedViews = new List<View>();
            Debug.WriteLine("Refreshing views");

            if (currentWellboreId > -1)
            {
                var views = await retrieveViewsFromJSONManager();

                refreshedViews.AddRange(views);
            }
            giveViewListToObservers(refreshedViews);
            Debug.WriteLine("Done refreshing views");
        }

        protected virtual async Task<View[]> retrieveViewsFromJSONManager()
        {
            return await JSONManager.getViews(currentWellboreId);
        }


        public void setCurrentView(View view)
        {
            currentView = view;
            giveCurrentViewToObservers();
        }

        public void addPanel(PanelType type, string name)
        {
            Debug.WriteLine("Adding a new panel");
            List<Panel> panels = new List<Panel>();
            int panelPosition;
            int panelId;
            if (currentView.Panels.Length == 0)
            {
                panelPosition = 0;
                panelId = 0;
            }
            else
            {
                int maxPanelPosition = currentView.Panels[0].Pos;
                int maxPanelId = currentView.Panels[0].Id;
                foreach (Panel panel in currentView.Panels)
                {
                    if (panel.Pos > maxPanelPosition)
                    {
                        maxPanelPosition = panel.Pos;
                    }

                    if (panel.Id > maxPanelId)
                    {
                        maxPanelId = panel.Id;
                    }
                }
                panelPosition = maxPanelPosition + 1;
                panelId = maxPanelId + 1;

                panels.AddRange(currentView.Panels);
            }

            Debug.WriteLine("Creating the new Panel via constructor with viewID " + currentView.Id);
            Panel newPanel = new Panel(panelId, panelPosition, 0, 0, currentView.Id, name, type);

            newPanel.Visualizations = new VisualComponent[0];

            panels.Add(newPanel);
            currentView.Panels = panels.ToArray();

            Debug.WriteLine("Posting view " + currentView.ToString());
            postViewToJSONManager(currentView);
            giveCurrentViewToObservers();
        }

        public void addItem(int panelId, int curveId)
        {
            Debug.WriteLine("Adding a new item");
            List<VisualComponent> visuals = new List<VisualComponent>();
            Panel toAddToPanel = null;

            foreach (Panel panel in currentView.Panels)
            {
                if (panel.Id.Equals(panelId))
                {
                    toAddToPanel = panel;
                    break;
                }
            }

            if (toAddToPanel != null)
            {
                int visualId = 0;
                int xPos = 0;
                int yPos = 0;
                string jsFile = ""; //Not used ever

                VisualComponent visual = new VisualComponent(visualId, xPos, yPos, jsFile, toAddToPanel.Id,
                    new int[] {curveId});
                visuals.AddRange(toAddToPanel.Visualizations);
                visuals.Add(visual);
                toAddToPanel.Visualizations = visuals.ToArray();

                Debug.WriteLine("Posting view " + currentView.ToString());
                postViewToJSONManager(currentView);
                giveCurrentViewToObservers();
            }
        }

        protected virtual void postViewToJSONManager(View view)
        {
            JSONManager.postView(view);
        }

        public void addView(string name) {
            View newView = new View(new Panel[] { }, currentWellboreId, name);
            Debug.WriteLine("Adding view to be posted: " + newView.Name);
            postViewToJSONManager(newView);
            refreshViews();
        }

        public void deleteView(View view)
        {
            if (view != null)
            {
                deleteViewToJSONManager(view);
                refreshViews();
            }
        }

        public void deletePanel(Panel panel)
        {
            if (panel != null)
            {
                List<Panel> panelList = new List<Panel>();
                panelList.AddRange(currentView.Panels);

                panelList.Remove(panel);
                currentView.Panels = panelList.ToArray();
                postViewToJSONManager(currentView);
                refreshViews();
            }
        }

        public void deleteItem(Panel panel, VisualComponent item)
        {
            if (panel != null && item != null)
            {
                List<VisualComponent> itemList = new List<VisualComponent>();
                List<Panel> panelList = new List<Panel>();
                Panel newPanel = new Panel(panel.Id, panel.Pos, panel.XDim, panel.YDim, panel.ViewId, panel.Name,
                    panel.panelType);
                itemList.AddRange(panel.Visualizations);

                itemList.Remove(item);
                newPanel.Visualizations = itemList.ToArray();

                panelList.AddRange(currentView.Panels);
                panelList.Remove(panel);
                panelList.Add(newPanel);

                currentView.Panels = panelList.ToArray();
                postViewToJSONManager(currentView);
                refreshViews();
            }
        }

        protected virtual void deleteViewToJSONManager(View view)
        {
            JSONManager.deleteView(view);
        }

        public IDisposable Subscribe(IObserver<List<View>> observer)
        {
            if (!listViewObservers.Contains(observer))
            {
                listViewObservers.Add(observer);
            }
            return new ListViewUnsubscriber(listViewObservers, observer);
        }

        protected void giveViewListToObservers(List<View> views)
        {
            //observers should never be null
            foreach (IObserver<List<View>> observer in listViewObservers)
            {
                observer.OnNext(views);
            }
        }

        protected void giveViewListErrorToObservers(Exception exc)
        {
            //observers should never be null
            foreach (IObserver<List<View>> observer in listViewObservers)
            {
                observer.OnError(exc);
            }
        }

        //Copied from https://msdn.microsoft.com/en-us/library/dd783449%28v=vs.110%29.aspx
        protected class ListViewUnsubscriber : IDisposable
        {
            private List<IObserver<List<View>>> _observers;
            private IObserver<List<View>> _observer;

            public ListViewUnsubscriber(List<IObserver<List<View>>> observers, IObserver<List<View>> observer)
            {
                this._observers = observers;
                this._observer = observer;
            }

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }
        }

        public IDisposable Subscribe(IObserver<View> observer)
        {
            if (!viewObservers.Contains(observer))
            {
                viewObservers.Add(observer);
            }
            giveCurrentViewToObservers();
            return new ViewUnsubscriber(viewObservers, observer);
        }

        //Copied from https://msdn.microsoft.com/en-us/library/dd783449%28v=vs.110%29.aspx
        protected class ViewUnsubscriber : IDisposable
        {
            private List<IObserver<View>> _observers;
            private IObserver<View> _observer;

            public ViewUnsubscriber(List<IObserver<View>> observers, IObserver<View> observer)
            {
                this._observers = observers;
                this._observer = observer;
            }

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }
        }

        protected void giveCurrentViewToObservers()
        {
            //observers should never be null
            foreach (IObserver<View> observer in viewObservers)
            {
                observer.OnNext(currentView);
            }
        }
    }
}
