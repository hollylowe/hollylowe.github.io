﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SDIApp
{
    [DataContract]
    public class VisualComponent
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int XPos { get; set; }
        [DataMember]
        public int YPos { get; set; }
        [DataMember]
        public string JsFile { get; set; }
        [DataMember]
        public int PanelId { get; set; }
        [DataMember]
        public int[] CurveIds { get; set; }

        public VisualComponent(int id, int xPos, int yPos, string jsFile, int panelId, int[] curveIds)
        {
            this.Id = id;
            this.XPos = xPos;
            this.YPos = yPos;
            this.JsFile = jsFile;
            this.PanelId = panelId;
            this.CurveIds = curveIds;
        }

        public override string ToString()
        {
            string itemString = "";
            if (CurveIds == null || CurveIds.Length <= 0)
            {
                itemString += "Item without a selected curve";
            }
            else
            {
                itemString += "Item displaying curves";
                foreach (int curveId in CurveIds)
                {
                    itemString += " " + curveId ;
                }
            }

            return itemString;
        }
    }
}
