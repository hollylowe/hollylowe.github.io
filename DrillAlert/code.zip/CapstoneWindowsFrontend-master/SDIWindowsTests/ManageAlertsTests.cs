﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestPlatform.UnitTestFramework;
using SDIApp;
using System.Threading.Tasks;

namespace SDIApp
{
    [TestClass]
    public class ManageAlertsTests : ManageAlerts
    {/*
        private static ManageAlerts manageAlerts;

        [ClassInitialize]
        public static async Task ManageAlertsSetup(TestContext context)
        {
            await Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal,
                () =>
                {
                    manageAlerts = new ManageAlerts();
                }
                );
        }

        [Microsoft.VisualStudio.TestPlatform.UnitTestFramework.AppContainer.UITestMethod]
        public void TestGetWells()
        {
            Assert.IsNull(manageAlerts.getWells());
            manageAlerts.retrieveWells();
            Assert.IsNotNull(manageAlerts.getWells());
        }

        [Microsoft.VisualStudio.TestPlatform.UnitTestFramework.AppContainer.UITestMethod]
        public void TestGetWellbores()
        {
            Assert.IsNull(manageAlerts.getWellbores());
            manageAlerts.WellSelectionChanged(null, null);
            Assert.IsNotNull(manageAlerts.getWellbores());
        }

        [Microsoft.VisualStudio.TestPlatform.UnitTestFramework.AppContainer.UITestMethod]
        public void TestGetCurves()
        {
            Assert.IsNull(manageAlerts.getCurves());
            manageAlerts.WellboreSelectionChanged(null, null);
            Assert.IsNotNull(manageAlerts.getCurves());
        }

        [Microsoft.VisualStudio.TestPlatform.UnitTestFramework.AppContainer.UITestMethod]
        public void TestGetAssociatedAlerts()
        {
            Assert.IsNull(manageAlerts.getAssociatedAlerts());
            manageAlerts.ParameterSelectionChanged(null, null);
            Assert.IsNotNull(manageAlerts.getAssociatedAlerts());
        }*/
    }
}
