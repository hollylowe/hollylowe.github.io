﻿using System;
using System.Diagnostics;
using System.Linq;
using Microsoft.VisualStudio.TestPlatform.UnitTestFramework;
using SDIApp;

namespace SDIWindowsTests
{
    [TestClass]
    public class ViewManagerTest
    {
        TestViewManager viewManager;// = new TestViewManager();
        private TestViewManagerViewObserver viewObserver;
        private TestViewManagerListObserver listObserver;

        [TestInitialize]
        public void TestPrep()
        {
            viewManager =  new TestViewManager();
            viewObserver = new TestViewManagerViewObserver();
            listObserver = new TestViewManagerListObserver();
            viewManager.Subscribe(viewObserver);
            viewManager.Subscribe(listObserver);
        }

        [TestMethod]
        [Timeout(2)]  // Milliseconds
        public void TestViewManagerNull()
        {
            Assert.IsNotNull(viewManager, "View Manager instance is null.");
        }

        [TestMethod]
        public void TestViewManagerChangeWellbore()
        {
            viewManager.changeWellboreID(2);
            Assert.AreEqual(viewManager.currentWellboreId , 2);
        }

        [TestMethod]
        public void TestViewManagerChangeView()
        {
            View testView = new View(new Panel[] { }, 0, "Test View");
            viewManager.setCurrentView(testView);
            View currentView = viewManager.currentView;
            Assert.AreEqual(currentView, testView);
        }

        [TestMethod]
        public void TestViewObserver()
        {
            Assert.IsTrue(viewManager.getViewObservers().Any());
        }

        [TestMethod]
        public void TestViewManagerAddView()
        {
            viewManager.changeWellboreID(0);
            viewManager.addView("Test View");
            Assert.IsTrue(viewManager.views.Any());
        }

        [TestMethod]
        public void TestViewManagerDeleteView()
        {
            viewManager.changeWellboreID(0);
            viewManager.addView("Test View");
            viewManager.deleteView(viewManager.views[0]);
            Assert.IsFalse(viewManager.views.Any());
        }

        [TestMethod]
        public void TestViewManagerAddPanel()
        {
            viewManager.changeWellboreID(0);
            viewManager.addView("Test View");
            var testView = viewManager.views[0];
            viewManager.setCurrentView(testView);
            viewManager.addPanel(PanelType.Plot, "Test Panel", 0);
            testView = viewManager.views[0];
            Assert.IsTrue(testView.Panels.Any());
        }

        [TestMethod]
        public void TestViewManagerAdd3Panels()
        {
            viewManager.changeWellboreID(0);
            viewManager.addView("Test View");
            var testView = viewManager.views[0];
            viewManager.setCurrentView(testView);
            viewManager.addPanel(PanelType.Plot, "Test Panel", 0);
            viewManager.addPanel(PanelType.Plot, "Test Panel 2", 0);
            viewManager.addPanel(PanelType.Plot, "Test Panel 3", 0);
            testView = viewManager.views[0];
            Assert.AreEqual(3, testView.Panels.Count());
        }
    }
}
