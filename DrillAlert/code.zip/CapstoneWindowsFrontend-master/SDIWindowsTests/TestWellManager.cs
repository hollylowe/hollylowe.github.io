﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SDIApp;

namespace SDIWindowsTests
{
    public class TestWellManager : WellManager
    {
        protected static TestWellManager instance;

        protected TestWellManager()
        {
            observers = new List<IObserver<List<Well>>>();
            wells = new List<Well>();
        }

        public static TestWellManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new TestWellManager();
                }
                return instance;
            }
        }

        public void addWell(Well newWell)
        {
            wells.Add(newWell);
        }
    }
}
