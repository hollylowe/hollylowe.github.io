﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SDIApp;

namespace SDIWindowsTests
{
    public class TestViewManager : ViewManager
    {
        public List<View> views; 

        public TestViewManager() {
            listViewObservers = new List<IObserver<List<View>>>();
            viewObservers = new List<IObserver<View>>();
            views = new List<View>();
        }

        protected override Task<View[]> retrieveViewsFromJSONManager()
        {
            Task<View[]> taskViews = new Task<View[]>(() => views.ToArray());
            taskViews.Start();
            return taskViews;
        }

        protected override void postViewToJSONManager(View view)
        {
            views.Add(view);
        }

        protected override void deleteViewToJSONManager(View view)
        {
            views.Remove(view);
        }

        public List<IObserver<View>> getViewObservers()
        {
            return viewObservers;
        }
    }

    public class TestViewManagerViewObserver : IObserver<View>
    {
        public View currentView;
        
        public void OnCompleted()
        {
 	        throw new NotImplementedException();
        }

        public void OnError(Exception error)
        {
 	        throw new NotImplementedException();
        }

        public void OnNext(View value)
        {
            currentView = value;
        }
    }

    public class TestViewManagerListObserver : IObserver<List<View>>
    {
        public List<View> allViews;

        public void OnCompleted()
        {
            throw new NotImplementedException();
        }

        public void OnError(Exception error)
        {
            throw new NotImplementedException();
        }

        public void OnNext(List<View> value)
        {
            allViews = value;
        }
    }
}
